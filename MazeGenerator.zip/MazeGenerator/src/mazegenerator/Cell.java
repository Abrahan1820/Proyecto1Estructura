package mazegenerator;



public class Cell {
    

    private int x;
    private int y;
    private boolean visited;
    private boolean isWall;
    private boolean isPath;
    private boolean isStart;
    private boolean isEnd;
    private Cell next;
    private boolean lados[] = {true, true, true, true};
    private boolean puertas[] = {false,false,false,false};
    private Cell below,top,right,left;



    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        this.visited = false;
        this.isWall = false;
        this.isPath = false;
        this.isStart = false;
        this.next = null;
    }


    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public Cell getNext() {
        return next;
    }

    public void setNext(Cell next) {
        this.next = next;
    }

    public boolean isWall() {
        return isWall;
    }

    public void setWall(boolean isWall) {
        this.isWall = isWall;
    }

    public boolean isPath() {
        return isPath;
    }

    public void setPath(boolean isPath) {
        this.isPath = isPath;
    }

    public boolean isStart() {
        return isStart;
    }

    public void setStart(boolean isStart) {
        this.isStart = isStart;
    }

    public boolean isEnd() {
        return isEnd;
    }

    public void setEnd(boolean isEnd) {
        this.isEnd = isEnd;
    }

    public boolean[] getLados() {
        return lados;
    }

    public void setLados(boolean[] lados) {
        this.lados = lados;
    }

    public boolean[] getPuertas() {
        return puertas;
    }

    public void setPuertas(boolean[] puertas) {
        this.puertas = puertas;
    }

    public Cell getBelow() {
        return below;
    }

    public void setBelow(Cell below) {
        this.below = below;
    }

    public Cell getTop() {
        return top;
    }

    public void setTop(Cell top) {
        this.top = top;
    }

    public Cell getRight() {
        return right;
    }

    public void setRight(Cell right) {
        this.right = right;
    }

    public Cell getLeft() {
        return left;
    }

    public void setLeft(Cell left) {
        this.left = left;
    }

    public void printVecinos() {
        System.out.println("x: " + x + " y: " + y);
        if (below != null) {
            System.out.println("below: " + below.getX() + " " + below.getY());
        }
        if (top != null) {
            System.out.println("top: " + top.getX() + " " + top.getY());
        }
        if (right != null) {
            System.out.println("right: " + right.getX() + " " + right.getY());
        }
        if (left != null) {
            System.out.println("left: " + left.getX() + " " + left.getY());
        }
    }


    public void setLado(int i, boolean b) {
        lados[i] = b;
    }



    public void printLados() {
        System.out.println("x: " + x + " y: " + y);
        System.out.println("lado 0: " + lados[0]);
        System.out.println("lado 1: " + lados[1]);
        System.out.println("lado 2: " + lados[2]);
        System.out.println("lado 3: " + lados[3]);
    }

    public Cell[] getNeighbors() {
        Cell[] vecinos = new Cell[4];
        vecinos[0] = below;
        vecinos[1] = top;
        vecinos[2] = right;
        vecinos[3] = left;
        return vecinos;
    } 

    public void removeWall(Cell next){

        if(next.getX() == this.getX() && next.getY() == this.getY() - 1){
            this.setLado(0, false);
            next.setLado(1, false);
        }
        if(next.getX() == this.getX() && next.getY() == this.getY() + 1){
            this.setLado(1, false);
            next.setLado(0, false);
        }
        if(next.getX() == this.getX() + 1 && next.getY() == this.getY()){
            this.setLado(2, false);
            next.setLado(3, false);
        }
        if(next.getX() == this.getX() - 1 && next.getY() == this.getY()){
            this.setLado(3, false);
            next.setLado(2, false);
        }

    }



}
