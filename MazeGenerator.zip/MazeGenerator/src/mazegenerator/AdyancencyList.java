package mazegenerator;

/**
 * this class is going to be the adyancency list of the graph
 */


public class AdyancencyList {
    
    private Cell primero;
    private Cell ultimo;
    private int size;

    public AdyancencyList() {
        this.primero = null;
        this.ultimo = null;
        this.size = 0;
    }

    public Cell getPrimero() {
        return primero;
    }

    public void setPrimero(Cell primero) {
        this.primero = primero;
    }

    public Cell getUltimo() {
        return ultimo;
    }

    public void setUltimo(Cell ultimo) {
        this.ultimo = ultimo;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void add(Cell cell){
        if(primero == null){
            primero = cell;
            ultimo = cell;
        }else{
            ultimo.setNext(cell);
            ultimo = cell;
        }
        size++;
    }

    public void remove(Cell cell){
        if(primero == cell){
            primero = primero.getNext();
        }else{
            Cell aux = primero;
            while(aux.getNext() != cell){
                aux = aux.getNext();
            }
            aux.setNext(cell.getNext());
            if(ultimo == cell){
                ultimo = aux;
            }
        }
        size--;
    }

    public Cell getCell(int x, int y){
        Cell aux = primero;
        while(aux != null){
            if(aux.getX() == x && aux.getY() == y){
                return aux;
            }
            aux = aux.getNext();
        }
        return null;
    }


    public void print(){
        Cell aux = primero;
        while(aux != null){
            System.out.println("x: " + aux.getX() + " y: " + aux.getY());
            aux = aux.getNext();
        }
    }


    public boolean isEmpty(){
        return primero == null;
    }

    public Cell get(int random) {
        //get a random cell from the list

        Cell aux = primero;
        int i = 0;
        while(i < random){
            aux = aux.getNext();
            i++;
        }
        return aux;
    }

    public boolean contains(Cell cell) {
        //check if the list contains a cell
        Cell aux = primero;
        while(aux != null){
            if(aux.getX() == cell.getX() && aux.getY() == cell.getY()){
                return true;
            }
            aux = aux.getNext();
        }
        return false;
    }


    




}
